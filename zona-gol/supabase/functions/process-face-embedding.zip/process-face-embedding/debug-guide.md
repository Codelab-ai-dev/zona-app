# Debugging Guide for Face Embedding Function

This guide will help you test and debug the `process-face-embedding` Edge Function in your Coolify-hosted Supabase setup.

## 1. Testing the Function Directly

I've created a test script (`test-function.js`) that simulates a direct call to your Edge Function. To use it:

```bash
# Navigate to the function directory
cd /Users/gustavo/Desktop/zona-app/zona-gol/supabase/functions/process-face-embedding

# Install node-fetch if not already installed
npm install node-fetch

# Run the test script with your environment variables
NEXT_PUBLIC_SUPABASE_URL=https://your-supabase-url.supabase.co \
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key \
node test-function.js
```

Replace `your-supabase-url.supabase.co` and `your-anon-key` with your actual Supabase URL and anon key. Also update the `PLAYER_ID` in the script to use an actual player ID from your database.

## 2. Common Issues and Solutions

### Function Not Found (404 Error)

If you get a 404 error, the function is not properly deployed or not accessible at the expected URL.

**Solution:**
- Verify the function is deployed using one of the methods in the manual deployment instructions
- Check if the function URL is correct (should be `https://your-supabase-url/functions/v1/process-face-embedding`)
- Ensure your Coolify Supabase service has Edge Functions enabled

### Authentication Error (401/403 Error)

If you get a 401 or 403 error, there's an issue with the authentication.

**Solution:**
- Verify your anon key is correct
- Check if the function is set to require authentication
- Ensure your JWT token is valid if using authenticated requests

### Function Execution Error (500 Error)

If you get a 500 error, the function is deployed but encountering an error during execution.

**Solution:**
- Check the function logs in your Coolify dashboard
- Verify the environment variables are set correctly in your Coolify environment:
  - `SUPABASE_URL`
  - `SUPABASE_SERVICE_ROLE_KEY`
- Make sure the database schema matches what the function expects

## 3. Verifying Frontend Integration

To verify the frontend is correctly calling the function:

1. Add console logs in the `processFaceEmbedding` function in `player-management.tsx`:

```typescript
const processFaceEmbedding = async (playerId: string, photoDataUrl: string) => {
  try {
    console.log('🔵 Processing face embedding for player:', playerId)
    console.log('🔵 Supabase URL:', process.env.NEXT_PUBLIC_SUPABASE_URL)
    
    const supabase = createClientSupabaseClient()
    
    console.log('🔵 Calling Edge Function...')
    const { data, error } = await supabase.functions.invoke('process-face-embedding', {
      body: {
        playerId,
        photoDataUrl
      }
    })
    
    console.log('🔵 Edge Function response:', data, error)
    // Rest of the function...
```

2. Open your browser's developer console when creating/updating a player with a photo
3. Look for the logs to trace the execution flow and identify where it's failing

## 4. Checking Database Updates

After calling the function, verify if the database was updated:

```sql
-- Run this in your Supabase SQL editor
SELECT id, enrollment_status, face_quality_score 
FROM players 
WHERE id = 'your-player-id' 
LIMIT 1;
```

This will show if the face embedding process updated the player record successfully.

## 5. Coolify-Specific Troubleshooting

If you're still having issues with your Coolify-hosted Supabase:

1. Check if the Edge Functions service is running:
   ```bash
   # SSH into your VPS
   ssh your-username@your-vps-hostname
   
   # Check if the Edge Functions service is running
   docker ps | grep edge-functions
   ```

2. Verify the Edge Functions logs:
   ```bash
   # View logs for the Edge Functions service
   docker logs $(docker ps -q --filter name=edge-functions) --tail 100
   ```

3. Restart the Edge Functions service if needed:
   ```bash
   # Find the container ID
   docker ps | grep edge-functions
   
   # Restart the container
   docker restart <container-id>
   ```
