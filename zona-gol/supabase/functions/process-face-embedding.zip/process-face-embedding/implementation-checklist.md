# Face Embedding Implementation Checklist

Use this checklist to ensure your face embedding function is properly deployed and working in your Coolify-hosted Supabase environment.

## Deployment Steps

- [ ] **Package the Edge Function**
  ```bash
  cd /Users/gustavo/Desktop/zona-app/zona-gol/supabase/functions
  zip -r process-face-embedding.zip process-face-embedding
  ```

- [ ] **Deploy to Coolify**
  - [ ] Upload the zip file to your VPS
  - [ ] Extract to the Supabase functions directory
  - [ ] Register the function with your Supabase instance

## Environment Configuration

- [ ] **Set Required Environment Variables in Coolify**
  - [ ] `SUPABASE_URL` - Your Supabase instance URL
  - [ ] `SUPABASE_SERVICE_ROLE_KEY` - Service role key for database access

- [ ] **Verify Frontend Environment Variables**
  - [ ] `NEXT_PUBLIC_SUPABASE_URL` - Correctly points to your Coolify Supabase instance
  - [ ] `NEXT_PUBLIC_SUPABASE_ANON_KEY` - Valid anon key for your instance

## Testing

- [ ] **Run the Test Script**
  ```bash
  cd /Users/gustavo/Desktop/zona-app/zona-gol/supabase/functions/process-face-embedding
  NEXT_PUBLIC_SUPABASE_URL=https://your-supabase-url \
  NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key \
  node test-function.js
  ```

- [ ] **Check Function Response**
  - [ ] Function returns a 200 status code
  - [ ] Response includes `success: true`
  - [ ] Response includes a 512-dimensional embedding array
  - [ ] Response includes a quality score

- [ ] **Verify Database Updates**
  - [ ] Player record is updated with face embedding
  - [ ] Enrollment status is set to "enrolled"
  - [ ] Face quality score is set

## Frontend Integration

- [ ] **Test Player Creation Flow**
  - [ ] Create a new player with a photo
  - [ ] Check browser console for successful function call
  - [ ] Verify player record in database has face embedding

- [ ] **Test Player Update Flow**
  - [ ] Update an existing player with a new photo
  - [ ] Check browser console for successful function call
  - [ ] Verify player record in database has updated face embedding

## Troubleshooting

If you encounter issues:

- [ ] **Check Function Logs in Coolify Dashboard**
  - Look for error messages or exceptions

- [ ] **Verify Network Requests**
  - Use browser developer tools to check the network request to the Edge Function
  - Ensure the URL, headers, and payload are correct

- [ ] **Test Direct API Call**
  - Use cURL or Postman to call the function directly:
  ```bash
  curl -X POST "https://your-supabase-url/functions/v1/process-face-embedding" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer your-anon-key" \
    -d '{"playerId": "test-player-id", "photoDataUrl": "data:image/png;base64,..."}'
  ```

## Future Enhancements

- [ ] **Replace Mock Embedding with Real Face Recognition**
  - Integrate with a face recognition API
  - Update the Edge Function to use the API
  - Add proper error handling for API failures

- [ ] **Add Face Quality Validation**
  - Reject photos with poor quality
  - Provide feedback to users about photo quality

- [ ] **Implement Face Matching**
  - Compare new face embeddings with existing ones
  - Detect duplicate players or identity issues
