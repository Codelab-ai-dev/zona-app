// Test script for the process-face-embedding Edge Function
// This script helps debug issues with the function by simulating a direct call

const fetch = require('node-fetch');

// Configuration - Replace these values with your actual Supabase details
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://your-supabase-url.supabase.co';
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'your-anon-key';
const PLAYER_ID = 'test-player-id'; // Replace with an actual player ID from your database

// Create a simple base64 image for testing
const createTestImage = () => {
  // This is a minimal 1x1 pixel transparent PNG in base64
  return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
};

// Function to test the Edge Function
const testFaceEmbeddingFunction = async () => {
  try {
    console.log('🔵 Testing process-face-embedding function...');
    console.log(`🔵 Using Supabase URL: ${SUPABASE_URL}`);
    
    const response = await fetch(`${SUPABASE_URL}/functions/v1/process-face-embedding`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        playerId: PLAYER_ID,
        photoDataUrl: createTestImage()
      })
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Function call failed:', response.status, response.statusText);
      console.error('Error details:', errorText);
      return;
    }
    
    const data = await response.json();
    console.log('✅ Function call successful!');
    console.log('Response data:', JSON.stringify(data, null, 2));
    
    // Check if the response contains the expected fields
    if (data.success && data.embedding) {
      console.log('✅ Face embedding generated successfully!');
      console.log(`Embedding dimensions: ${data.embedding.length}`);
      console.log(`Quality score: ${data.qualityScore}`);
    } else {
      console.error('❌ Function did not return expected data structure');
    }
  } catch (error) {
    console.error('❌ Error testing function:', error);
  }
};

// Run the test
testFaceEmbeddingFunction();
