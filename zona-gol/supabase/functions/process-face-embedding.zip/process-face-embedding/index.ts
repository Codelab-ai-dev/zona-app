// @deno-types="https://deno.land/std@0.168.0/http/server.ts"
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
// @deno-types="https://esm.sh/@supabase/supabase-js@2"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface FaceProcessingRequest {
  playerId: string
  photoDataUrl: string
}

interface FaceProcessingResponse {
  success: boolean
  playerId: string
  embedding?: number[]
  qualityScore?: number
  error?: string
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client with service role key for server-side operations
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    )

    const { playerId, photoDataUrl }: FaceProcessingRequest = await req.json()

    console.log('🔵 Processing face embedding for player:', playerId)

    if (!playerId || !photoDataUrl) {
      throw new Error('Missing required fields: playerId or photoDataUrl')
    }

    // Validate photo format (should be base64 data URL)
    if (!photoDataUrl.startsWith('data:image/')) {
      throw new Error('Invalid photo format. Expected base64 data URL.')
    }

    // Extract base64 data from data URL
    const base64Data = photoDataUrl.split(',')[1]
    if (!base64Data) {
      throw new Error('Invalid base64 data in photo')
    }

    // Convert base64 to bytes
    const photoBytes = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0))
    
    console.log('🔵 Photo size:', photoBytes.length, 'bytes')

    // TODO: Here you would integrate with a face recognition service
    // For now, we'll create a mock embedding and set enrollment status
    
    // Mock face processing (replace with actual face recognition service)
    const mockEmbedding = Array(512).fill(0).map(() => Math.random() * 2 - 1) // Random 512-dim vector
    const mockQualityScore = 0.85 // Mock quality score
    
    console.log('🔵 Generated mock embedding with', mockEmbedding.length, 'dimensions')

    // Update player record with face embedding
    const { data: updatedPlayer, error: updateError } = await supabaseClient
      .from('players')
      .update({
        face_embedding: mockEmbedding,
        face_quality_score: mockQualityScore,
        enrollment_status: 'enrolled',
        enrollment_metadata: {
          processed_at: new Date().toISOString(),
          processing_version: '1.0.0',
          face_detected: true,
          quality_checks: {
            sharpness: 0.85,
            lighting: 0.80,
            face_size: 0.90,
            frontal_pose: 0.88
          }
        },
        updated_at: new Date().toISOString()
      })
      .eq('id', playerId)
      .select()
      .single()

    if (updateError) {
      console.error('❌ Error updating player with face embedding:', updateError)
      throw updateError
    }

    console.log('✅ Successfully updated player with face embedding:', updatedPlayer.id)

    const response: FaceProcessingResponse = {
      success: true,
      playerId: updatedPlayer.id,
      embedding: mockEmbedding,
      qualityScore: mockQualityScore
    }

    return new Response(
      JSON.stringify(response),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )

  } catch (error) {
    console.error('❌ Face processing error:', error)
    
    // Handle the unknown error type properly
    const errorMessage = error instanceof Error 
      ? error.message 
      : 'Unknown error occurred during face processing'
    
    const errorResponse: FaceProcessingResponse = {
      success: false,
      playerId: '',
      error: errorMessage
    }

    return new Response(
      JSON.stringify(errorResponse),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      },
    )
  }
})

/* To deploy this function:
1. Make sure you have Supabase CLI installed
2. Run: supabase functions deploy process-face-embedding
3. Set the required environment variables in Supabase dashboard:
   - SUPABASE_URL (auto-set)
   - SUPABASE_SERVICE_ROLE_KEY (auto-set)

Note: This implementation uses mock face processing. For production, you should:
1. Integrate with a real face recognition service (AWS Rekognition, Azure Face API, etc.)
2. Add proper error handling for different image formats
3. Implement face detection and quality validation
4. Add security measures to prevent abuse
5. Consider rate limiting and image size validation
*/